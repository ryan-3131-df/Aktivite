# Aktivite Kalkanı

Günlük hareket hedefini korumak için geliştirilmiş bir Android uygulaması. İlk açılışta bir **profil** oluşturursun ve sınırlarını kendin belirlersin: hedef türü, günlük hedef, kilit saati, kilitlenecek uygulamalar ve kurallar. Belirlediğin saate kadar hedefini tamamlamazsan, seçtiğin uygulamalar gece yarısına kadar açılmaz. Veriler Samsung Health'ten Health Connect üzerinden okunur.

## Ekranlar
| Ekran | İçerik |
|---|---|
| **Profil oluşturma (ilk açılış)** | 0 Karşılama → 1 Profil ve hedef → 2 Kilit saati → 3 Uygulamalar → 4 Kurallar ve özet → 5 İzinler |
| **Ana ekran** | İlerleme halkası, durum kartı (kilide kalan süre / kalkan etkin / hedef tamam), özet kutucukları, korunan uygulamalar |
| **Profil ve sınırlar** | Tüm profil ayarlarını düzenleme ve izin durumları |
| **Kilit ekranı** | Kilitli bir uygulama açılınca çıkar; kalan miktarı gösterir, "Yenile" ile kilidi anında kaldırır |

## Profilde belirlenen sınırlar
- **Hedef türü:** Adım, Mesafe (km) veya Aktif kalori
- **Günlük hedef:** Kaydırıcı veya hazır seçenekler (Hafif / Dengeli / Aktif / Sporcu)
- **Kilit saati:** Bu saatten 00:00'a kadar geçerli
- **Uygulamalar:** Instagram, TikTok, X, Facebook, Snapchat, Threads, YouTube, Reddit, Pinterest. Telefonda yüklü olanlar ikonlarıyla üstte listelenir.
- **Tarayıcıları da kilitle:** Web sürümleri üzerinden kilidi aşmayı önler
- **Katı mod:** Kilit etkinken hedef düşürülemez, saat ileri alınamaz, listeden uygulama çıkarılamaz. Yalnızca yeni uygulama eklenebilir.
- **Hatırlatma:** Kilide 1 saat kala hedef tutmuyorsa bildirim gönderilir

## Kod yapısı
```
app/src/main/java/com/adimkilidi/
├─ Profile.kt                  Profil modeli, Metric, uygulama listeleri, Prefs
├─ ActivityRepository.kt       Health Connect okuma (adım / mesafe / aktif kalori)
├─ LockRules.kt                Kilit mantığı
├─ ActivitySyncWorker.kt       15 dk'da bir senkron + hatırlatma bildirimi
├─ BlockerAccessibilityService.kt  Uygulama açılışını yakalayıp engeller
├─ BlockActivity.kt            Kilit ekranı
├─ MainActivity.kt             Yönlendirme + sistem izinleri
└─ ui/
   ├─ Theme.kt                 Marka renkleri (teal + turuncu), açık/koyu tema, tipografi
   ├─ Components.kt            İlerleme halkası, editörler, izin kartları
   ├─ Setup.kt                 İzin durumu modeli
   ├─ OnboardingScreen.kt      Profil oluşturma sihirbazı
   ├─ HomeScreen.kt            Ana ekran
   └─ ProfileScreen.kt         Profil düzenleme
```

## Derleme
1. Klasörü Android Studio'da aç. Gradle senkronizasyonu kendiliğinden başlar.
2. Telefonda Geliştirici seçenekleri › USB hata ayıklama'yı aç, telefonu bağla ve ▶ Run'a bas.

## S24 Ultra'da kurulum
Uygulamanın son adımı bunları sırayla gösterir. Özetle:
1. **Samsung Health › Ayarlar › Health Connect** yolundan adım, mesafe ve kalori paylaşımını aç.
2. Uygulamada **aktivite verisi** ve **arka planda okuma** iznini ver.
3. **Kısıtlı ayarlar:** Ayarlar › Uygulamalar › Aktivite Kalkanı › ⋮ › *Kısıtlı ayarlara izin ver*. Bu adım, Play Store dışından yüklenen uygulamalar için gerekli.
4. **Erişilebilirlik › Yüklü uygulamalar › Aktivite Kalkanı › Aç**
5. **Pil › Kısıtlanmamış** seç. Ayrıca *Hiç uyumayan uygulamalar* listesine ekle.

## Bilinen sınırlar
- Erişilebilirlik servisini kapatmak veya uygulamayı silmek kalkanı devre dışı bırakır.
- Mesafe ve kalori verisi, Samsung Health'in Health Connect'e ne paylaştığına bağlıdır. En güvenilir ölçüm adımdır.
- Samsung Health verisi Health Connect'e birkaç dakika gecikmeyle yazılabilir. Kilit ekranındaki "Yenile" butonu bu yüzden var.
