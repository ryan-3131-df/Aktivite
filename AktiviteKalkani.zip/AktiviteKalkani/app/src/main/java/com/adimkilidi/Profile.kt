package com.adimkilidi

import android.content.Context
import java.text.NumberFormat
import java.time.LocalDate
import java.util.Locale

private val TR: Locale = Locale.forLanguageTag("tr-TR")

/** Günlük aktivite hedefi türü. Mesafe metre, kalori kcal olarak saklanır. */
enum class Metric(
    val title: String,
    val unit: String,
    val min: Int,
    val max: Int,
    val step: Int,
    val default: Int,
    val presets: List<Pair<String, Int>>,
) {
    STEPS(
        "Adım", "adım", 2_000, 30_000, 500, 10_000,
        listOf("Hafif" to 5_000, "Dengeli" to 8_000, "Aktif" to 10_000, "Sporcu" to 15_000),
    ),
    DISTANCE(
        "Mesafe", "km", 1_000, 30_000, 500, 5_000,
        listOf("Hafif" to 3_000, "Dengeli" to 5_000, "Aktif" to 8_000, "Sporcu" to 12_000),
    ),
    CALORIES(
        "Aktif kalori", "kcal", 100, 2_000, 50, 400,
        listOf("Hafif" to 200, "Dengeli" to 300, "Aktif" to 500, "Sporcu" to 800),
    );

    fun format(v: Long): String = when (this) {
        DISTANCE -> String.format(TR, "%.1f", v / 1000.0)
        else -> NumberFormat.getIntegerInstance(TR).format(v)
    }

    fun withUnit(v: Long) = "${format(v)} $unit"
}

/** Sosyal medya uygulamaları (paket adı -> görünen ad). */
val SOCIAL_APPS: Map<String, String> = linkedMapOf(
    "com.instagram.android" to "Instagram",
    "com.zhiliaoapp.musically" to "TikTok",
    "com.ss.android.ugc.trill" to "TikTok (Asya)",
    "com.twitter.android" to "X (Twitter)",
    "com.facebook.katana" to "Facebook",
    "com.snapchat.android" to "Snapchat",
    "com.instagram.barcelona" to "Threads",
    "com.google.android.youtube" to "YouTube",
    "com.reddit.frontpage" to "Reddit",
    "com.pinterest" to "Pinterest",
)

/** "Tarayıcıları da kilitle" açıksa engellenen tarayıcılar (web sürümlerinden kaçışı önler). */
val BROWSERS: Map<String, String> = linkedMapOf(
    "com.sec.android.app.sbrowser" to "Samsung Internet",
    "com.android.chrome" to "Chrome",
    "org.mozilla.firefox" to "Firefox",
    "com.opera.browser" to "Opera",
    "com.microsoft.emmx" to "Edge",
    "com.brave.browser" to "Brave",
)

fun appLabel(pkg: String) = SOCIAL_APPS[pkg] ?: BROWSERS[pkg] ?: pkg

data class Profile(
    val name: String = "",
    val metric: Metric = Metric.STEPS,
    val goal: Int = Metric.STEPS.default,
    val lockHour: Int = 21,
    val lockMinute: Int = 0,
    val blocked: Set<String> = setOf(
        "com.instagram.android", "com.zhiliaoapp.musically", "com.ss.android.ugc.trill",
        "com.twitter.android", "com.facebook.katana", "com.snapchat.android",
    ),
    val blockBrowsers: Boolean = false,
    val strict: Boolean = true,
    val remind: Boolean = true,
) {
    val lockTimeText get() = "%02d:%02d".format(lockHour, lockMinute)
    val effectiveBlocked get() = if (blockBrowsers) blocked + BROWSERS.keys else blocked
}

object Prefs {
    private fun p(c: Context) = c.getSharedPreferences("adim_kilidi", Context.MODE_PRIVATE)

    fun onboardingDone(c: Context) = p(c).getBoolean("onboarding_done", false)
    fun setOnboardingDone(c: Context) = p(c).edit().putBoolean("onboarding_done", true).apply()

    fun profile(c: Context): Profile {
        val d = Profile()
        val prefs = p(c)
        val metric = runCatching { Metric.valueOf(prefs.getString("metric", null)!!) }
            .getOrDefault(d.metric)
        return Profile(
            name = prefs.getString("name", d.name) ?: d.name,
            metric = metric,
            goal = prefs.getInt("goal", metric.default),
            lockHour = prefs.getInt("lock_hour", d.lockHour),
            lockMinute = prefs.getInt("lock_minute", d.lockMinute),
            blocked = prefs.getStringSet("blocked", d.blocked)?.toSet() ?: d.blocked,
            blockBrowsers = prefs.getBoolean("block_browsers", d.blockBrowsers),
            strict = prefs.getBoolean("strict", d.strict),
            remind = prefs.getBoolean("remind", d.remind),
        )
    }

    fun saveProfile(c: Context, pr: Profile) {
        val metricChanged = profile(c).metric != pr.metric
        val e = p(c).edit()
        // Hedef türü değişince eski türün önbelleği geçersiz olur
        if (metricChanged) e.remove("progress_day")
        e.putString("name", pr.name.trim())
            .putString("metric", pr.metric.name)
            .putInt("goal", pr.goal)
            .putInt("lock_hour", pr.lockHour)
            .putInt("lock_minute", pr.lockMinute)
            .putStringSet("blocked", pr.blocked)
            .putBoolean("block_browsers", pr.blockBrowsers)
            .putBoolean("strict", pr.strict)
            .putBoolean("remind", pr.remind)
            .apply()
    }

    /** Bugünkü ilerlemeyi (seçili metrik biriminde) saklar. */
    fun saveProgress(c: Context, metric: Metric, value: Long) = p(c).edit()
        .putLong("progress", value)
        .putString("progress_metric", metric.name)
        .putString("progress_day", LocalDate.now().toString())
        .apply()

    /** Bugüne ve seçili metriğe ait ilerleme; yoksa null. */
    fun todayProgress(c: Context): Long? {
        val prefs = p(c)
        if (prefs.getString("progress_day", null) != LocalDate.now().toString()) return null
        if (prefs.getString("progress_metric", null) != profile(c).metric.name) return null
        return prefs.getLong("progress", 0L)
    }

    fun lastReminderDay(c: Context) = p(c).getString("reminder_day", null)
    fun setReminderSentToday(c: Context) =
        p(c).edit().putString("reminder_day", LocalDate.now().toString()).apply()
}
