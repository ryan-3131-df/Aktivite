package com.adimkilidi.ui

import android.content.Context
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.DirectionsWalk
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.core.graphics.drawable.toBitmap
import com.adimkilidi.BROWSERS
import com.adimkilidi.Metric
import com.adimkilidi.SOCIAL_APPS
import kotlin.math.roundToInt

// ───────────────────────── Temel parçalar ─────────────────────────

fun metricIcon(m: Metric): ImageVector = when (m) {
    Metric.STEPS -> Icons.AutoMirrored.Rounded.DirectionsWalk
    Metric.DISTANCE -> Icons.Rounded.Straighten
    Metric.CALORIES -> Icons.Rounded.LocalFireDepartment
}

@Composable
fun IconBadge(
    icon: ImageVector,
    container: Color = MaterialTheme.colorScheme.primaryContainer,
    content: Color = MaterialTheme.colorScheme.onPrimaryContainer,
    size: Dp = 44.dp,
) {
    Box(
        Modifier.size(size).clip(RoundedCornerShape(size * 0.32f)).background(container),
        contentAlignment = Alignment.Center,
    ) { Icon(icon, null, tint = content, modifier = Modifier.size(size * 0.52f)) }
}

@Composable
fun SectionCard(
    title: String,
    modifier: Modifier = Modifier,
    subtitle: String? = null,
    icon: ImageVector? = null,
    content: @Composable ColumnScope.() -> Unit,
) {
    Surface(
        modifier = modifier.fillMaxWidth(),
        shape = MaterialTheme.shapes.large,
        color = MaterialTheme.colorScheme.surfaceContainerLowest,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(Modifier.padding(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                if (icon != null) IconBadge(icon, size = 40.dp)
                Column {
                    Text(title, style = MaterialTheme.typography.titleMedium)
                    if (subtitle != null) Text(
                        subtitle,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
            content()
        }
    }
}

@Composable
fun Banner(
    icon: ImageVector,
    text: String,
    container: Color = MaterialTheme.colorScheme.tertiaryContainer,
    content: Color = MaterialTheme.colorScheme.onTertiaryContainer,
) {
    Row(
        Modifier.fillMaxWidth().clip(MaterialTheme.shapes.medium).background(container).padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
    ) {
        Icon(icon, null, tint = content)
        Text(text, style = MaterialTheme.typography.bodyMedium, color = content)
    }
}

@Composable
fun StatTile(icon: ImageVector, label: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = MaterialTheme.shapes.medium,
        color = MaterialTheme.colorScheme.surfaceContainerLowest,
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant),
    ) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
            Text(value, style = MaterialTheme.typography.titleMedium.merge(TabularNums), maxLines = 1)
            Text(label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 1)
        }
    }
}

/** 270° açık halka ilerleme göstergesi. */
@Composable
fun ProgressRing(
    progress: Float,
    color: Color,
    modifier: Modifier = Modifier,
    stroke: Dp = 16.dp,
    content: @Composable BoxScope.() -> Unit,
) {
    val animated by animateFloatAsState(progress.coerceIn(0f, 1f), tween(900), label = "ring")
    val track = MaterialTheme.colorScheme.surfaceContainerHigh
    Box(modifier, contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val s = stroke.toPx()
            val arcSize = Size(size.width - s, size.height - s)
            val tl = Offset(s / 2, s / 2)
            drawArc(track, 135f, 270f, false, tl, arcSize, style = Stroke(s, cap = StrokeCap.Round))
            if (animated > 0f) drawArc(color, 135f, 270f * animated, false, tl, arcSize, style = Stroke(s, cap = StrokeCap.Round))
        }
        content()
    }
}

// ───────────────────────── Profil editörleri ─────────────────────────

@Composable
fun MetricSelector(selected: Metric, onSelect: (Metric) -> Unit, enabled: Boolean = true) {
    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Metric.entries.forEach { m ->
            val on = m == selected
            val cs = MaterialTheme.colorScheme
            Column(
                Modifier
                    .weight(1f)
                    .clip(MaterialTheme.shapes.medium)
                    .background(if (on) cs.primaryContainer else cs.surfaceContainer)
                    .border(
                        if (on) 2.dp else 1.dp,
                        if (on) cs.primary else cs.outlineVariant,
                        MaterialTheme.shapes.medium,
                    )
                    .clickable(enabled = enabled) { onSelect(m) }
                    .padding(vertical = 14.dp)
                    .alpha(if (enabled) 1f else 0.5f),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(6.dp),
            ) {
                Icon(metricIcon(m), null, tint = if (on) cs.primary else cs.onSurfaceVariant)
                Text(
                    m.title,
                    style = MaterialTheme.typography.labelLarge,
                    color = if (on) cs.onPrimaryContainer else cs.onSurfaceVariant,
                )
            }
        }
    }
}

@Composable
fun GoalEditor(metric: Metric, goal: Int, onChange: (Int) -> Unit, enabled: Boolean = true) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Row(verticalAlignment = Alignment.Bottom) {
            Text(
                metric.format(goal.toLong()),
                style = MaterialTheme.typography.displayMedium.merge(TabularNums),
                color = MaterialTheme.colorScheme.primary,
            )
            Spacer(Modifier.width(8.dp))
            Text(
                "${metric.unit} / gün",
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                modifier = Modifier.padding(bottom = 10.dp),
            )
        }
        Slider(
            value = goal.toFloat(),
            onValueChange = { v ->
                val snapped = ((v - metric.min) / metric.step).roundToInt() * metric.step + metric.min
                onChange(snapped.coerceIn(metric.min, metric.max))
            },
            valueRange = metric.min.toFloat()..metric.max.toFloat(),
            enabled = enabled,
        )
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            metric.presets.forEach { (label, value) ->
                FilterChip(
                    selected = goal == value,
                    onClick = { onChange(value) },
                    enabled = enabled,
                    label = { Text("$label · ${metric.format(value.toLong())}") },
                )
            }
        }
    }
}

@Composable
fun LockTimeEditor(hour: Int, minute: Int, onChange: (Int, Int) -> Unit, enabled: Boolean = true) {
    var showPicker by remember { mutableStateOf(false) }
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(
            Modifier
                .fillMaxWidth()
                .clip(MaterialTheme.shapes.medium)
                .background(MaterialTheme.colorScheme.surfaceContainer)
                .clickable(enabled = enabled) { showPicker = true }
                .padding(horizontal = 20.dp, vertical = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Column(Modifier.weight(1f)) {
                Text("Kilit başlangıcı", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
                Text(
                    "%02d:%02d".format(hour, minute),
                    style = MaterialTheme.typography.displayMedium.merge(TabularNums),
                )
                Text("→ 00:00'a kadar", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (enabled) Icon(Icons.Rounded.Edit, "Değiştir", tint = MaterialTheme.colorScheme.primary)
        }
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf(19, 20, 21, 22, 23).forEach { h ->
                FilterChip(
                    selected = hour == h && minute == 0,
                    onClick = { onChange(h, 0) },
                    enabled = enabled,
                    label = { Text("%02d:00".format(h)) },
                )
            }
        }
    }
    if (showPicker) {
        TimePickerDialog(hour, minute, onDismiss = { showPicker = false }) { h, m ->
            onChange(h, m); showPicker = false
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TimePickerDialog(h: Int, m: Int, onDismiss: () -> Unit, onConfirm: (Int, Int) -> Unit) {
    val state = rememberTimePickerState(initialHour = h, initialMinute = m, is24Hour = true)
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Kilit saatini seç") },
        text = { Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { TimePicker(state) } },
        confirmButton = { TextButton({ onConfirm(state.hour, state.minute) }) { Text("Tamam") } },
        dismissButton = { TextButton(onDismiss) { Text("Vazgeç") } },
    )
}

fun isInstalled(c: Context, pkg: String) =
    runCatching { c.packageManager.getPackageInfo(pkg, 0); true }.getOrDefault(false)

@Composable
fun AppIcon(pkg: String, label: String, size: Dp = 40.dp) {
    val ctx = LocalContext.current
    val bmp: ImageBitmap? = remember(pkg) {
        runCatching { ctx.packageManager.getApplicationIcon(pkg).toBitmap(128, 128).asImageBitmap() }.getOrNull()
    }
    if (bmp != null) {
        Image(bmp, label, Modifier.size(size).clip(RoundedCornerShape(size * 0.28f)))
    } else {
        Box(
            Modifier.size(size).clip(RoundedCornerShape(size * 0.28f)).background(MaterialTheme.colorScheme.surfaceContainerHigh),
            contentAlignment = Alignment.Center,
        ) { Text(label.take(1), style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

/**
 * @param noRemoval true ise (katı mod + kilit etkin) listeden uygulama çıkarılamaz, sadece eklenebilir.
 */
@Composable
fun AppsEditor(
    blocked: Set<String>,
    onBlockedChange: (Set<String>) -> Unit,
    blockBrowsers: Boolean,
    onBlockBrowsersChange: (Boolean) -> Unit,
    noRemoval: Boolean = false,
) {
    val ctx = LocalContext.current
    val apps = remember {
        SOCIAL_APPS.entries
            .map { Triple(it.key, it.value, isInstalled(ctx, it.key)) }
            .sortedByDescending { it.third }
    }
    Column {
        apps.forEachIndexed { i, (pkg, name, installed) ->
            val on = pkg in blocked
            Row(
                Modifier.fillMaxWidth().padding(vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(14.dp),
            ) {
                Box(Modifier.alpha(if (installed) 1f else 0.45f)) { AppIcon(pkg, name) }
                Column(Modifier.weight(1f)) {
                    Text(name, style = MaterialTheme.typography.bodyLarge, fontWeight = FontWeight.Medium)
                    if (!installed) Text("Yüklü değil", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(
                    checked = on,
                    enabled = !(noRemoval && on),
                    onCheckedChange = { onBlockedChange(if (it) blocked + pkg else blocked - pkg) },
                )
            }
            if (i < apps.lastIndex) HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)
        }
        Spacer(Modifier.height(12.dp))
        ToggleRow(
            icon = Icons.Rounded.Public,
            title = "Tarayıcıları da kilitle",
            subtitle = "Web sürümlerinden kaçışı önler (${BROWSERS.values.take(3).joinToString()}…)",
            checked = blockBrowsers,
            enabled = !(noRemoval && blockBrowsers),
            onChange = onBlockBrowsersChange,
        )
    }
}

@Composable
fun ToggleRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    checked: Boolean,
    onChange: (Boolean) -> Unit,
    enabled: Boolean = true,
) {
    Row(
        Modifier
            .fillMaxWidth()
            .clip(MaterialTheme.shapes.medium)
            .background(MaterialTheme.colorScheme.surfaceContainer)
            .clickable(enabled = enabled) { onChange(!checked) }
            .padding(14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(14.dp),
    ) {
        IconBadge(icon, size = 40.dp)
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        Switch(checked = checked, onCheckedChange = onChange, enabled = enabled)
    }
}

@Composable
fun RulesEditor(
    strict: Boolean, onStrict: (Boolean) -> Unit,
    remind: Boolean, onRemind: (Boolean) -> Unit,
    enabled: Boolean = true,
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        ToggleRow(
            Icons.Rounded.Shield, "Katı mod",
            "Kilit saatinde hedef, saat ve uygulama listesi gevşetilemez",
            strict, onStrict, enabled = enabled,
        )
        ToggleRow(
            Icons.Rounded.NotificationsActive, "Kilitten önce hatırlat",
            "Kilide 1 saat kala hedef tutmuyorsa bildirim gönder",
            remind, onRemind, enabled = enabled,
        )
    }
}

// ───────────────────────── İzin listesi ─────────────────────────

@Composable
fun PermissionList(setup: SetupState, actions: SetupActions, showNotifications: Boolean) {
    var n = 0
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        PermissionItem(
            ++n, Icons.Rounded.HealthAndSafety, "Health Connect",
            "Samsung Health verilerine erişim katmanı. One UI 6+ sürümlerde sistemde yerleşik.",
            setup.hcAvailable, true, "Yükle", actions::installHealthConnect,
        )
        PermissionItem(
            ++n, Icons.Rounded.Favorite, "Aktivite verisi izni",
            "Adım/mesafe/kalori okuma ve arka planda okuma. Samsung Health › Ayarlar › Health Connect'ten de veri paylaşımını aç.",
            setup.healthPerm && setup.backgroundPerm, true, "İzin ver", actions::requestHealthPermissions,
            enabled = setup.hcAvailable,
        )
        PermissionItem(
            ++n, Icons.Rounded.AdminPanelSettings, "Kısıtlı ayarlara izin ver",
            "Play Store dışından yüklendiyse gerekli: Uygulama bilgisi › ⋮ › Kısıtlı ayarlara izin ver.",
            setup.accessibility, true, "Uygulama bilgisi", actions::openAppInfo,
        )
        PermissionItem(
            ++n, Icons.Rounded.Accessibility, "Erişilebilirlik servisi",
            "Kilitli uygulama açıldığında devreye girer. Erişilebilirlik › Yüklü uygulamalar › Aktivite Kalkanı.",
            setup.accessibility, true, "Aç", actions::openAccessibilitySettings,
        )
        PermissionItem(
            ++n, Icons.Rounded.BatteryFull, "Pil kısıtlaması yok",
            "Samsung arka plan servislerini kapatabilir. Kilidin güvenilir çalışması için önerilir.",
            setup.battery, false, "Kaldır", actions::requestBatteryExemption,
        )
        if (showNotifications) PermissionItem(
            ++n, Icons.Rounded.Notifications, "Bildirimler",
            "Kilit öncesi hatırlatma için.",
            setup.notifications, false, "İzin ver", actions::requestNotifications,
        )
    }
}

@Composable
private fun PermissionItem(
    number: Int,
    icon: ImageVector,
    title: String,
    description: String,
    done: Boolean,
    required: Boolean,
    actionLabel: String,
    onAction: () -> Unit,
    enabled: Boolean = true,
) {
    val cs = MaterialTheme.colorScheme
    Surface(
        shape = MaterialTheme.shapes.medium,
        color = if (done) cs.primaryContainer.copy(alpha = 0.45f) else cs.surfaceContainerLowest,
        border = BorderStroke(1.dp, if (done) cs.primary.copy(alpha = 0.35f) else cs.outlineVariant),
    ) {
        Row(Modifier.fillMaxWidth().padding(14.dp), horizontalArrangement = Arrangement.spacedBy(14.dp)) {
            Box(
                Modifier.size(32.dp).clip(CircleShape)
                    .background(if (done) cs.primary else cs.surfaceContainerHigh),
                contentAlignment = Alignment.Center,
            ) {
                if (done) Icon(Icons.Rounded.Check, null, tint = cs.onPrimary, modifier = Modifier.size(18.dp))
                else Text("$number", style = MaterialTheme.typography.labelLarge, color = cs.onSurfaceVariant)
            }
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(icon, null, tint = cs.primary, modifier = Modifier.size(18.dp))
                    Text(title, style = MaterialTheme.typography.titleSmall)
                }
                Text(description, style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                if (!done) {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            if (required) "ZORUNLU" else "ÖNERİLEN",
                            style = MaterialTheme.typography.labelSmall,
                            color = if (required) cs.tertiary else cs.onSurfaceVariant,
                        )
                        Spacer(Modifier.weight(1f))
                        FilledTonalButton(onClick = onAction, enabled = enabled, contentPadding = PaddingValues(horizontal = 16.dp)) {
                            Text(actionLabel)
                        }
                    }
                }
            }
        }
    }
}
