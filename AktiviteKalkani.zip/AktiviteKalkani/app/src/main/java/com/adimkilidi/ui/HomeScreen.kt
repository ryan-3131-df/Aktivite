package com.adimkilidi.ui

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.adimkilidi.ActivityRepository
import com.adimkilidi.Prefs
import com.adimkilidi.SOCIAL_APPS
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.time.Duration
import java.time.LocalDate
import java.time.LocalTime
import java.time.format.DateTimeFormatter
import java.util.Locale

private val TR = Locale.forLanguageTag("tr-TR")

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun HomeScreen(setup: SetupState, tick: Int, actions: SetupActions, onOpenProfile: () -> Unit) {
    val ctx = LocalContext.current
    val profile = remember(tick) { Prefs.profile(ctx) }
    val repo = remember { ActivityRepository(ctx) }
    val scope = rememberCoroutineScope()

    var progress by remember { mutableStateOf(Prefs.todayProgress(ctx)) }
    var refreshing by remember { mutableStateOf(false) }
    var now by remember { mutableStateOf(LocalTime.now()) }

    LaunchedEffect(Unit) { while (true) { delay(30_000); now = LocalTime.now() } }
    LaunchedEffect(tick, setup.healthPerm) {
        progress = Prefs.todayProgress(ctx)
        if (setup.healthPerm) {
            refreshing = true
            repo.refresh()?.let { progress = it }
            refreshing = false
        }
    }

    val value = progress ?: 0L
    val goal = profile.goal.toLong()
    val reached = value >= goal
    val remaining = (goal - value).coerceAtLeast(0)
    val lockAt = LocalTime.of(profile.lockHour, profile.lockMinute)
    val lockActive = !now.isBefore(lockAt) && !reached
    val cs = MaterialTheme.colorScheme

    Scaffold(
        containerColor = cs.background,
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            "${greeting(now)}${if (profile.name.isNotBlank()) ", ${profile.name}" else ""}",
                            style = MaterialTheme.typography.titleLarge,
                        )
                        Text(
                            LocalDate.now().format(DateTimeFormatter.ofPattern("d MMMM EEEE", TR)),
                            style = MaterialTheme.typography.bodySmall,
                            color = cs.onSurfaceVariant,
                        )
                    }
                },
                actions = {
                    IconButton(
                        onClick = {
                            scope.launch {
                                refreshing = true
                                repo.refresh()?.let { progress = it }
                                refreshing = false
                            }
                        },
                        enabled = !refreshing && setup.healthPerm,
                    ) {
                        if (refreshing) CircularProgressIndicator(Modifier.size(20.dp), strokeWidth = 2.dp)
                        else Icon(Icons.Rounded.Refresh, "Yenile")
                    }
                    IconButton(onClick = onOpenProfile) { Icon(Icons.Rounded.AccountCircle, "Profil") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = cs.background),
            )
        },
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            if (setup.loaded && !setup.essentialsReady) {
                SectionCard(
                    "Kurulum tamamlanmadı",
                    subtitle = "Kalkan şu an uygulamaları kilitleyemez",
                    icon = Icons.Rounded.Warning,
                ) { PermissionList(setup, actions, showNotifications = profile.remind) }
            }

            // ── Ana ilerleme kartı ──
            Surface(
                shape = MaterialTheme.shapes.extraLarge,
                color = cs.surfaceContainerLowest,
                border = BorderStroke(1.dp, cs.outlineVariant),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(
                    Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(20.dp),
                ) {
                    ProgressRing(
                        progress = value.toFloat() / goal,
                        color = if (lockActive) cs.tertiary else cs.primary,
                        modifier = Modifier.size(232.dp),
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(metricIcon(profile.metric), null, tint = cs.onSurfaceVariant)
                            Text(
                                if (progress == null) "—" else profile.metric.format(value),
                                style = MaterialTheme.typography.displayMedium.merge(TabularNums),
                            )
                            Text(
                                "/ ${profile.metric.withUnit(goal)}",
                                style = MaterialTheme.typography.bodyMedium,
                                color = cs.onSurfaceVariant,
                            )
                            Spacer(Modifier.height(6.dp))
                            Text(
                                "%${((value * 100) / goal).coerceAtMost(999)}",
                                style = MaterialTheme.typography.labelLarge,
                                color = if (lockActive) cs.tertiary else cs.primary,
                            )
                        }
                    }
                    StatusPill(
                        reached = reached,
                        lockActive = lockActive,
                        remainingText = profile.metric.withUnit(remaining),
                        untilLock = Duration.between(now, lockAt),
                    )
                }
            }

            // ── Özet kutucukları ──
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                StatTile(Icons.Rounded.EmojiEvents, "Kalan", profile.metric.withUnit(remaining), Modifier.weight(1f))
                StatTile(Icons.Rounded.Schedule, "Kilit saati", profile.lockTimeText, Modifier.weight(1f))
                StatTile(
                    Icons.Rounded.Lock, "Kilitli",
                    "${profile.blocked.size}${if (profile.blockBrowsers) "+" else ""} uygulama",
                    Modifier.weight(1f),
                )
            }

            // ── Korunan uygulamalar ──
            SectionCard("Korunan uygulamalar", icon = Icons.Rounded.Shield) {
                val installed = remember(profile) {
                    profile.blocked.filter { isInstalled(ctx, it) }
                }
                if (installed.isEmpty()) {
                    Text("Listede yüklü uygulama yok.", style = MaterialTheme.typography.bodyMedium, color = cs.onSurfaceVariant)
                } else {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        installed.take(6).forEach { AppIcon(it, SOCIAL_APPS[it] ?: it, size = 44.dp) }
                    }
                }
                OutlinedButton(onClick = onOpenProfile, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Rounded.Tune, null, Modifier.size(18.dp))
                    Spacer(Modifier.width(8.dp))
                    Text("Profili ve sınırları düzenle")
                }
            }

            Text(
                "Veri kaynağı: Samsung Health → Health Connect · 15 dakikada bir güncellenir",
                style = MaterialTheme.typography.bodySmall,
                color = cs.onSurfaceVariant,
                modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
            )
        }
    }
}

@Composable
private fun StatusPill(reached: Boolean, lockActive: Boolean, remainingText: String, untilLock: Duration) {
    val cs = MaterialTheme.colorScheme
    data class S(val icon: ImageVector, val title: String, val body: String, val bg: Color, val fg: Color)
    val s = when {
        reached -> S(
            Icons.Rounded.LockOpen, "Bugün hedef tamam",
            "Kalkan bu gece devreye girmeyecek. Tebrikler!",
            cs.primaryContainer, cs.onPrimaryContainer,
        )
        lockActive -> S(
            Icons.Rounded.Lock, "Kalkan etkin",
            "$remainingText daha hareket et, kilit anında açılsın.",
            cs.tertiaryContainer, cs.onTertiaryContainer,
        )
        else -> S(
            Icons.Rounded.Schedule, "Kilide ${formatDuration(untilLock)} kaldı",
            "Hedefe $remainingText uzaktasın.",
            cs.secondaryContainer, cs.onSecondaryContainer,
        )
    }
    Surface(color = s.bg, shape = MaterialTheme.shapes.medium, modifier = Modifier.fillMaxWidth()) {
        Row(
            Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp),
        ) {
            Icon(s.icon, null, tint = s.fg)
            Column {
                Text(s.title, style = MaterialTheme.typography.titleSmall, color = s.fg)
                Text(s.body, style = MaterialTheme.typography.bodyMedium, color = s.fg)
            }
        }
    }
}

private fun greeting(t: LocalTime) = when (t.hour) {
    in 5..11 -> "Günaydın"
    in 12..17 -> "İyi günler"
    else -> "İyi akşamlar"
}

private fun formatDuration(d: Duration): String {
    val mins = d.toMinutes().coerceAtLeast(0)
    val h = mins / 60
    val m = mins % 60
    return when {
        h == 0L -> "$m dk"
        m == 0L -> "$h sa"
        else -> "$h sa $m dk"
    }
}
