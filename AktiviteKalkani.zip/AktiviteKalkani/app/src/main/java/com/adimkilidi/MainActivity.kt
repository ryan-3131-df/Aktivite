package com.adimkilidi

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.health.connect.client.PermissionController
import com.adimkilidi.ui.AppTheme
import com.adimkilidi.ui.HomeScreen
import com.adimkilidi.ui.OnboardingScreen
import com.adimkilidi.ui.ProfileScreen
import com.adimkilidi.ui.SetupActions
import com.adimkilidi.ui.SetupState

class MainActivity : ComponentActivity(), SetupActions {

    /** Her artışta izin durumları ve veriler yeniden okunur. */
    private var tick by mutableIntStateOf(0)

    private val healthLauncher =
        registerForActivityResult(PermissionController.createRequestPermissionResultContract()) { tick++ }

    private val notificationLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        Notifier.createChannel(this)
        ActivitySyncWorker.schedule(this)

        setContent {
            AppTheme {
                var screen by rememberSaveable {
                    mutableStateOf(if (Prefs.onboardingDone(this)) "home" else "onboarding")
                }
                val setup by produceState(SetupState(), tick) { value = SetupState.load(this@MainActivity) }

                when (screen) {
                    "onboarding" -> OnboardingScreen(setup, this) {
                        Prefs.setOnboardingDone(this)
                        screen = "home"; tick++
                    }
                    "profile" -> {
                        BackHandler { screen = "home"; tick++ }
                        ProfileScreen(setup, this) { screen = "home"; tick++ }
                    }
                    else -> HomeScreen(setup, tick, this) { screen = "profile" }
                }
            }
        }
    }

    override fun onResume() {
        super.onResume()
        tick++ // ayarlardan dönünce durumları yenile
    }

    // ── SetupActions ──

    override fun installHealthConnect() {
        startActivity(
            Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=com.google.android.apps.healthdata"))
        )
    }

    override fun requestHealthPermissions() = healthLauncher.launch(ActivityRepository.ALL_PERMISSIONS)

    override fun openAppInfo() {
        startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName")))
    }

    override fun openAccessibilitySettings() {
        startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
    }

    @SuppressLint("BatteryLife")
    override fun requestBatteryExemption() {
        startActivity(
            Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName"))
        )
    }

    override fun requestNotifications() {
        if (Build.VERSION.SDK_INT >= 33) notificationLauncher.launch(Manifest.permission.POST_NOTIFICATIONS)
    }
}
