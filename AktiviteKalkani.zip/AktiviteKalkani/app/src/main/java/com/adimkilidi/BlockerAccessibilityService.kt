package com.adimkilidi

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.launch

/**
 * Ön plana gelen uygulamayı izler. Kilit saatinde, hedef tamamlanmamışken
 * profildeki bir uygulama açılırsa ana ekrana atar ve kilit ekranını gösterir.
 * Ekran içeriğini okumaz; yalnızca paket adını görür.
 */
class BlockerAccessibilityService : AccessibilityService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private val repo by lazy { ActivityRepository(this) }
    private var lastRefresh = 0L

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg = event.packageName?.toString() ?: return
        if (pkg !in Prefs.profile(this).effectiveBlocked || !LockRules.isLockTime(this)) return

        // Önbelleğe göre anında karar ver; uygulama bir an bile kullanılamasın
        if (LockRules.shouldBlock(this, pkg)) block(pkg)

        // Arkadan veriyi tazele; hedef tutmuşsa kilit ekranı kendini açar
        val now = System.currentTimeMillis()
        if (now - lastRefresh > 60_000) {
            lastRefresh = now
            scope.launch { repo.refresh() }
        }
    }

    private fun block(pkg: String) {
        performGlobalAction(GLOBAL_ACTION_HOME)
        startActivity(
            Intent(this, BlockActivity::class.java)
                .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
                .putExtra(BlockActivity.EXTRA_APP, appLabel(pkg))
        )
    }

    override fun onInterrupt() {}

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }
}
