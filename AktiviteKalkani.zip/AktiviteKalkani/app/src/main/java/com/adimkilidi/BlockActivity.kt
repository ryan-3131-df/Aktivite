package com.adimkilidi

import android.content.Intent
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Lock
import androidx.compose.material.icons.rounded.LockOpen
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.adimkilidi.ui.AppTheme
import com.adimkilidi.ui.IconBadge
import com.adimkilidi.ui.ProgressRing
import com.adimkilidi.ui.TabularNums
import kotlinx.coroutines.launch

/** Kilitli bir uygulama açılınca gösterilen tam ekran. */
class BlockActivity : ComponentActivity() {

    companion object { const val EXTRA_APP = "app" }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        val appName = intent.getStringExtra(EXTRA_APP) ?: "Bu uygulama"
        setContent {
            AppTheme {
                BackHandler { goHome() }
                Surface(Modifier.fillMaxSize(), color = MaterialTheme.colorScheme.background) {
                    BlockScreen(appName)
                }
            }
        }
    }

    private fun goHome() {
        startActivity(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        )
        finish()
    }

    @Composable
    private fun BlockScreen(appName: String) {
        val ctx = this
        val profile = remember { Prefs.profile(ctx) }
        val repo = remember { ActivityRepository(ctx) }
        val scope = rememberCoroutineScope()
        var value by remember { mutableStateOf(Prefs.todayProgress(ctx)) }
        var loading by remember { mutableStateOf(true) }

        LaunchedEffect(Unit) {
            repo.refresh()?.let { value = it }
            loading = false
        }

        val goal = profile.goal.toLong()
        val v = value ?: 0L
        val done = v >= goal
        val cs = MaterialTheme.colorScheme

        Column(
            Modifier.fillMaxSize().systemBarsPadding().padding(28.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(20.dp, Alignment.CenterVertically),
        ) {
            IconBadge(
                if (done) Icons.Rounded.LockOpen else Icons.Rounded.Lock,
                container = if (done) cs.primaryContainer else cs.tertiaryContainer,
                content = if (done) cs.onPrimaryContainer else cs.onTertiaryContainer,
                size = 64.dp,
            )
            Text(
                if (done) "Hedef tamam!" else "$appName kilitli",
                style = MaterialTheme.typography.headlineMedium,
                textAlign = TextAlign.Center,
            )
            Text(
                when {
                    done -> "Kalkan kalktı. Uygulamayı tekrar açabilirsin."
                    value == null && !loading -> "Aktivite verisi okunamadı. Aktivite Kalkanı'nda izinleri kontrol et."
                    else -> "${profile.lockTimeText} itibarıyla günlük hedefin tamamlanmadı. " +
                        "${profile.metric.withUnit(goal - v)} daha hareket et, kilit anında açılsın."
                },
                style = MaterialTheme.typography.bodyLarge,
                color = cs.onSurfaceVariant,
                textAlign = TextAlign.Center,
            )
            ProgressRing(
                progress = v.toFloat() / goal,
                color = if (done) cs.primary else cs.tertiary,
                modifier = Modifier.size(200.dp),
                stroke = 14.dp,
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(
                        if (value == null) "—" else profile.metric.format(v),
                        style = MaterialTheme.typography.headlineLarge.merge(TabularNums),
                    )
                    Text("/ ${profile.metric.withUnit(goal)}", style = MaterialTheme.typography.bodySmall, color = cs.onSurfaceVariant)
                }
            }
            Spacer(Modifier.height(4.dp))
            Button(
                enabled = !loading,
                onClick = {
                    loading = true
                    scope.launch { repo.refresh()?.let { value = it }; loading = false }
                },
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(vertical = 14.dp),
            ) {
                if (loading) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp, color = cs.onPrimary)
                else Icon(Icons.Rounded.Refresh, null, Modifier.size(18.dp))
                Spacer(Modifier.width(8.dp))
                Text(if (loading) "Güncelleniyor…" else "Aktiviteyi yenile")
            }
            OutlinedButton(
                onClick = { goHome() },
                modifier = Modifier.fillMaxWidth(),
                contentPadding = PaddingValues(vertical = 14.dp),
            ) { Text(if (done) "Kapat" else "Ana ekrana dön") }
        }
    }
}
