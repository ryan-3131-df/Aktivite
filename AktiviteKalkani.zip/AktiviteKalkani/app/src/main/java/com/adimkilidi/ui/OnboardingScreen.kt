package com.adimkilidi.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.automirrored.rounded.ArrowForward
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import com.adimkilidi.Metric
import com.adimkilidi.Prefs
import com.adimkilidi.Profile

private const val TOTAL_STEPS = 6 // 0: karşılama, 1-4: profil, 5: izinler

/**
 * İlk açılışta profil oluşturma sihirbazı.
 * Her "İleri"de taslak kaydedilir; uygulama kapansa da kalınan yerden devam edilir.
 */
@Composable
fun OnboardingScreen(setup: SetupState, actions: SetupActions, onFinish: () -> Unit) {
    val ctx = LocalContext.current
    var step by rememberSaveable { mutableIntStateOf(0) }
    var draft by remember { mutableStateOf(Prefs.profile(ctx)) }

    val canNext = when (step) {
        1 -> draft.name.isNotBlank()
        3 -> draft.blocked.isNotEmpty() || draft.blockBrowsers
        else -> true
    }

    fun next() {
        Prefs.saveProfile(ctx, draft)
        if (step < TOTAL_STEPS - 1) step++ else onFinish()
    }

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            if (step > 0) Column(Modifier.statusBarsPadding().padding(horizontal = 24.dp, vertical = 12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        "Adım $step / ${TOTAL_STEPS - 1}",
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.weight(1f),
                    )
                    Text(
                        listOf("", "Profil", "Kilit saati", "Uygulamalar", "Kurallar", "İzinler")[step],
                        style = MaterialTheme.typography.labelLarge,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(
                    progress = { step / (TOTAL_STEPS - 1f) },
                    modifier = Modifier.fillMaxWidth().height(6.dp).clip(CircleShape),
                    drawStopIndicator = {},
                )
            }
        },
        bottomBar = {
            Surface(color = MaterialTheme.colorScheme.background) {
                Row(
                    Modifier.fillMaxWidth().navigationBarsPadding().imePadding().padding(horizontal = 24.dp, vertical = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    if (step > 0) {
                        TextButton(onClick = { step-- }) {
                            Icon(Icons.AutoMirrored.Rounded.ArrowBack, null, Modifier.size(18.dp))
                            Spacer(Modifier.width(6.dp)); Text("Geri")
                        }
                    }
                    Spacer(Modifier.weight(1f))
                    val label = when {
                        step == 0 -> "Profilimi oluştur"
                        step == 4 -> "Kaydet ve devam et"
                        step == TOTAL_STEPS - 1 && setup.essentialsReady -> "Kalkanı etkinleştir"
                        step == TOTAL_STEPS - 1 -> "Şimdilik atla"
                        else -> "Devam"
                    }
                    Button(
                        onClick = ::next,
                        enabled = canNext,
                        contentPadding = PaddingValues(horizontal = 24.dp, vertical = 14.dp),
                    ) {
                        Text(label)
                        if (step < TOTAL_STEPS - 1) {
                            Spacer(Modifier.width(8.dp))
                            Icon(Icons.AutoMirrored.Rounded.ArrowForward, null, Modifier.size(18.dp))
                        }
                    }
                }
            }
        },
    ) { pad ->
        AnimatedContent(
            targetState = step,
            transitionSpec = {
                val dir = if (targetState > initialState) 1 else -1
                (slideInHorizontally { it * dir / 3 } + fadeIn()) togetherWith
                    (slideOutHorizontally { -it * dir / 3 } + fadeOut())
            },
            modifier = Modifier.padding(pad).fillMaxSize(),
            label = "onboarding",
        ) { s ->
            Column(
                Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 24.dp, vertical = 8.dp),
                verticalArrangement = Arrangement.spacedBy(20.dp),
            ) {
                when (s) {
                    0 -> WelcomeStep()
                    1 -> ProfileStep(draft) { draft = it }
                    2 -> LockStep(draft) { draft = it }
                    3 -> AppsStep(draft) { draft = it }
                    4 -> RulesStep(draft) { draft = it }
                    else -> PermissionsStep(setup, actions, draft)
                }
                Spacer(Modifier.height(8.dp))
            }
        }
    }
}

@Composable
private fun StepHeader(title: String, subtitle: String) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.padding(top = 8.dp)) {
        Text(title, style = MaterialTheme.typography.headlineMedium)
        Text(subtitle, style = MaterialTheme.typography.bodyLarge, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

// ───────────── 0 · Karşılama ─────────────

@Composable
private fun WelcomeStep() {
    Column(
        Modifier.fillMaxWidth().padding(top = 40.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Box(
            Modifier.size(112.dp).clip(CircleShape).background(MaterialTheme.colorScheme.primaryContainer),
            contentAlignment = Alignment.Center,
        ) {
            Icon(Icons.Rounded.Shield, null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(56.dp))
        }
        Text("Aktivite Kalkanı", style = MaterialTheme.typography.headlineLarge, textAlign = TextAlign.Center)
        Text(
            "Günlük hareket hedefini koru. Hedefin tamamlanana kadar sosyal medya seni bekler.",
            style = MaterialTheme.typography.bodyLarge,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
            textAlign = TextAlign.Center,
        )
    }
    Spacer(Modifier.height(8.dp))
    Feature(Icons.Rounded.Favorite, "Samsung Health ile çalışır", "Adım, mesafe veya aktif kaloriyi Health Connect üzerinden okur.")
    Feature(Icons.Rounded.Lock, "Belirlediğin saatte kilit", "Hedef tutmazsa seçtiğin uygulamalar gece yarısına kadar açılmaz.")
    Feature(Icons.Rounded.EmojiEvents, "Hedefi tamamla, kilit kalksın", "Yürüyüşten döndüğün an erişim geri gelir.")
}

@Composable
private fun Feature(icon: ImageVector, title: String, text: String) {
    Row(horizontalArrangement = Arrangement.spacedBy(16.dp), verticalAlignment = Alignment.CenterVertically) {
        IconBadge(icon)
        Column(Modifier.weight(1f)) {
            Text(title, style = MaterialTheme.typography.titleSmall)
            Text(text, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

// ───────────── 1 · Profil ve hedef ─────────────

@Composable
private fun ProfileStep(draft: Profile, onChange: (Profile) -> Unit) {
    StepHeader("Profilini oluştur", "Sınırlarını sen belirle. İstediğin zaman profilinden değiştirebilirsin.")
    OutlinedTextField(
        value = draft.name,
        onValueChange = { onChange(draft.copy(name = it.take(24))) },
        label = { Text("Adın") },
        placeholder = { Text("Sana nasıl hitap edelim?") },
        leadingIcon = { Icon(Icons.Rounded.Person, null) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Words, imeAction = ImeAction.Done),
        shape = MaterialTheme.shapes.medium,
        modifier = Modifier.fillMaxWidth(),
    )
    SectionCard("Neyi takip edelim?", subtitle = "Günlük hedefinin ölçüsü", icon = Icons.Rounded.Tune) {
        MetricSelector(draft.metric, { m -> onChange(draft.copy(metric = m, goal = m.default)) })
        if (draft.metric != Metric.STEPS) {
            Text(
                "Mesafe ve kalori, Samsung Health'in Health Connect'e paylaştığı verilere bağlıdır. En güvenilir ölçüm adımdır.",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
        }
    }
    SectionCard("Günlük hedef", subtitle = "Gün içinde ulaşman gereken miktar", icon = metricIcon(draft.metric)) {
        GoalEditor(draft.metric, draft.goal, { onChange(draft.copy(goal = it)) })
    }
}

// ───────────── 2 · Kilit saati ─────────────

@Composable
private fun LockStep(draft: Profile, onChange: (Profile) -> Unit) {
    StepHeader(
        "Kilit ne zaman başlasın?",
        "Bu saate kadar hedefini tamamlamazsan, seçtiğin uygulamalar gece yarısına kadar kilitlenir.",
    )
    SectionCard("Kilit saati", icon = Icons.Rounded.Schedule) {
        LockTimeEditor(draft.lockHour, draft.lockMinute, { h, m -> onChange(draft.copy(lockHour = h, lockMinute = m)) })
    }
    Banner(
        Icons.Rounded.Bedtime,
        "Gece yarısı yeni gün başlar ve kilit kendiliğinden kalkar. Gün içinde hedefe ulaştığında kilit hiç devreye girmez.",
        container = MaterialTheme.colorScheme.secondaryContainer,
        content = MaterialTheme.colorScheme.onSecondaryContainer,
    )
}

// ───────────── 3 · Uygulamalar ─────────────

@Composable
private fun AppsStep(draft: Profile, onChange: (Profile) -> Unit) {
    StepHeader("Neler kilitlensin?", "Telefonunda yüklü olanlar üstte. En az bir uygulama seç.")
    SectionCard("Sosyal medya", icon = Icons.Rounded.Apps) {
        AppsEditor(
            blocked = draft.blocked,
            onBlockedChange = { onChange(draft.copy(blocked = it)) },
            blockBrowsers = draft.blockBrowsers,
            onBlockBrowsersChange = { onChange(draft.copy(blockBrowsers = it)) },
        )
    }
}

// ───────────── 4 · Kurallar + özet ─────────────

@Composable
private fun RulesStep(draft: Profile, onChange: (Profile) -> Unit) {
    StepHeader("Kurallar", "Kalkanın ne kadar sıkı olacağını seç.")
    RulesEditor(
        strict = draft.strict, onStrict = { onChange(draft.copy(strict = it)) },
        remind = draft.remind, onRemind = { onChange(draft.copy(remind = it)) },
    )
    ProfileSummary(draft)
}

@Composable
fun ProfileSummary(p: Profile) {
    SectionCard("Profil özeti", subtitle = p.name.ifBlank { "—" }, icon = Icons.Rounded.Person) {
        SummaryRow("Günlük hedef", p.metric.withUnit(p.goal.toLong()))
        SummaryRow("Kilit", "${p.lockTimeText} – 00:00")
        SummaryRow(
            "Kilitli uygulama",
            "${p.blocked.size}" + if (p.blockBrowsers) " + tarayıcılar" else "",
        )
        SummaryRow("Katı mod", if (p.strict) "Açık" else "Kapalı")
        SummaryRow("Hatırlatma", if (p.remind) "Kilitten 1 saat önce" else "Kapalı")
    }
}

@Composable
private fun SummaryRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth()) {
        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.weight(1f))
        Text(value, style = MaterialTheme.typography.bodyMedium.merge(TabularNums), color = MaterialTheme.colorScheme.onSurface)
    }
}

// ───────────── 5 · İzinler ─────────────

@Composable
private fun PermissionsStep(setup: SetupState, actions: SetupActions, draft: Profile) {
    StepHeader(
        "Kalkanı etkinleştir",
        "Android, kilidin çalışması için birkaç izin istiyor. Her birine dokun, açılan ekranda izni ver ve geri dön.",
    )
    if (setup.essentialsReady) {
        Banner(
            Icons.Rounded.CheckCircle,
            "Zorunlu adımlar tamam. Kalkan hazır!",
            container = MaterialTheme.colorScheme.primaryContainer,
            content = MaterialTheme.colorScheme.onPrimaryContainer,
        )
    }
    PermissionList(setup, actions, showNotifications = draft.remind)
}
