package com.adimkilidi

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import androidx.work.CoroutineWorker
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import androidx.work.WorkerParameters
import java.time.LocalDate
import java.time.LocalTime
import java.util.concurrent.TimeUnit

/** 15 dakikada bir aktiviteyi günceller; kilitten 1 saat önce hedef tutmuyorsa hatırlatır. */
class ActivitySyncWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {

    override suspend fun doWork(): Result {
        val c = applicationContext
        ActivityRepository(c).refresh()
        maybeRemind(c)
        return Result.success()
    }

    private fun maybeRemind(c: Context) {
        val pr = Prefs.profile(c)
        if (!pr.remind || LockRules.goalReached(c)) return
        if (Prefs.lastReminderDay(c) == LocalDate.now().toString()) return
        val lock = LocalTime.of(pr.lockHour, pr.lockMinute)
        if (lock.hour == 0) return // gece yarısına sarkan pencereyi atla
        val now = LocalTime.now()
        if (now.isBefore(lock.minusHours(1)) || !now.isBefore(lock)) return

        Notifier.remind(c, pr.metric.withUnit(LockRules.remaining(c)), pr.lockTimeText)
        Prefs.setReminderSentToday(c)
    }

    companion object {
        fun schedule(c: Context) {
            WorkManager.getInstance(c).enqueueUniquePeriodicWork(
                "activity_sync",
                ExistingPeriodicWorkPolicy.KEEP,
                PeriodicWorkRequestBuilder<ActivitySyncWorker>(15, TimeUnit.MINUTES).build(),
            )
        }
    }
}

object Notifier {
    private const val CHANNEL = "reminders"

    fun createChannel(c: Context) {
        val ch = NotificationChannel(CHANNEL, "Hedef hatırlatmaları", NotificationManager.IMPORTANCE_DEFAULT)
        ch.description = "Kilit saatinden önce hedefin tamamlanmadıysa haber verir"
        c.getSystemService(NotificationManager::class.java).createNotificationChannel(ch)
    }

    fun canNotify(c: Context) =
        Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(c, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED

    fun remind(c: Context, remainingText: String, lockTime: String) {
        if (!canNotify(c)) return
        val open = PendingIntent.getActivity(
            c, 0, Intent(c, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val n = NotificationCompat.Builder(c, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_lock_idle_alarm)
            .setContentTitle("Kilide 1 saatten az kaldı")
            .setContentText("$lockTime'den önce $remainingText daha. Kısa bir yürüyüş yeter!")
            .setContentIntent(open)
            .setAutoCancel(true)
            .build()
        try {
            NotificationManagerCompat.from(c).notify(1, n)
        } catch (_: SecurityException) { }
    }
}
