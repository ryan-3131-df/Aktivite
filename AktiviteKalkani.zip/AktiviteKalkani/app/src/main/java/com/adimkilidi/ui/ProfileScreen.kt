package com.adimkilidi.ui

import android.widget.Toast
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.ArrowBack
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import com.adimkilidi.LockRules
import com.adimkilidi.Prefs

/** Profil ve sınırları düzenleme. Katı modda kilit etkinken yalnızca sıkılaştırmaya izin verir. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ProfileScreen(setup: SetupState, actions: SetupActions, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val original = remember { Prefs.profile(ctx) }
    var draft by remember { mutableStateOf(original) }
    val locked = remember { LockRules.settingsLocked(ctx) }
    val dirty = draft != original

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = {
            TopAppBar(
                title = { Text("Profil ve sınırlar") },
                navigationIcon = {
                    IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Rounded.ArrowBack, "Geri") }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background),
            )
        },
        bottomBar = {
            if (dirty) Surface(color = MaterialTheme.colorScheme.background, tonalElevation = 3.dp) {
                Button(
                    onClick = {
                        Prefs.saveProfile(ctx, draft)
                        Toast.makeText(ctx, "Profil kaydedildi", Toast.LENGTH_SHORT).show()
                        onBack()
                    },
                    enabled = draft.name.isNotBlank() && (draft.blocked.isNotEmpty() || draft.blockBrowsers),
                    modifier = Modifier.fillMaxWidth().navigationBarsPadding().padding(20.dp),
                    contentPadding = PaddingValues(vertical = 14.dp),
                ) { Text("Değişiklikleri kaydet") }
            }
        },
    ) { pad ->
        Column(
            Modifier.padding(pad).fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp, vertical = 8.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp),
        ) {
            if (locked) {
                Banner(
                    Icons.Rounded.Shield,
                    "Katı mod etkin: kilit süresince hedef, saat ve kurallar değiştirilemez. Listeye yalnızca yeni uygulama ekleyebilirsin.",
                )
            }

            SectionCard("Profil", icon = Icons.Rounded.Person) {
                OutlinedTextField(
                    value = draft.name,
                    onValueChange = { draft = draft.copy(name = it.take(24)) },
                    label = { Text("Adın") },
                    singleLine = true,
                    shape = MaterialTheme.shapes.medium,
                    modifier = Modifier.fillMaxWidth(),
                )
            }

            SectionCard("Hedef türü", icon = Icons.Rounded.Tune) {
                MetricSelector(draft.metric, { m -> draft = draft.copy(metric = m, goal = m.default) }, enabled = !locked)
            }

            SectionCard("Günlük hedef", icon = metricIcon(draft.metric)) {
                GoalEditor(draft.metric, draft.goal, { draft = draft.copy(goal = it) }, enabled = !locked)
            }

            SectionCard("Kilit saati", icon = Icons.Rounded.Schedule) {
                LockTimeEditor(
                    draft.lockHour, draft.lockMinute,
                    { h, m -> draft = draft.copy(lockHour = h, lockMinute = m) },
                    enabled = !locked,
                )
            }

            SectionCard("Kilitlenecek uygulamalar", icon = Icons.Rounded.Apps) {
                AppsEditor(
                    blocked = draft.blocked,
                    onBlockedChange = { draft = draft.copy(blocked = it) },
                    blockBrowsers = draft.blockBrowsers,
                    onBlockBrowsersChange = { draft = draft.copy(blockBrowsers = it) },
                    noRemoval = locked,
                )
            }

            SectionCard("Kurallar", icon = Icons.Rounded.Shield) {
                RulesEditor(
                    strict = draft.strict, onStrict = { draft = draft.copy(strict = it) },
                    remind = draft.remind, onRemind = { draft = draft.copy(remind = it) },
                    enabled = !locked,
                )
            }

            SectionCard("İzinler ve kurulum", icon = Icons.Rounded.AdminPanelSettings) {
                PermissionList(setup, actions, showNotifications = draft.remind)
            }
            Spacer(Modifier.height(8.dp))
        }
    }
}
