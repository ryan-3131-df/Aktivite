package com.adimkilidi

import android.content.Context
import java.time.LocalTime

object LockRules {

    /** Kilit saati geldi mi? Kilit gece yarısına kadar sürer; yeni günde kalkar. */
    fun isLockTime(c: Context): Boolean {
        val pr = Prefs.profile(c)
        return !LocalTime.now().isBefore(LocalTime.of(pr.lockHour, pr.lockMinute))
    }

    /** Veri yoksa hedef tamamlanmamış sayılır (kapalı-güvenli). */
    fun goalReached(c: Context): Boolean {
        val v = Prefs.todayProgress(c) ?: return false
        return v >= Prefs.profile(c).goal
    }

    fun remaining(c: Context): Long =
        (Prefs.profile(c).goal - (Prefs.todayProgress(c) ?: 0L)).coerceAtLeast(0L)

    fun isLockActive(c: Context) = isLockTime(c) && !goalReached(c)

    /** Katı modda kilit etkinken profil değiştirilemez. */
    fun settingsLocked(c: Context) = Prefs.profile(c).strict && isLockActive(c)

    fun shouldBlock(c: Context, pkg: String) =
        pkg in Prefs.profile(c).effectiveBlocked && isLockActive(c)
}
