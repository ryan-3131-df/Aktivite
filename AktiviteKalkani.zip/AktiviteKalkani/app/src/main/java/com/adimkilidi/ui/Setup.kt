package com.adimkilidi.ui

import android.content.ComponentName
import android.content.Context
import android.os.PowerManager
import android.provider.Settings
import com.adimkilidi.ActivityRepository
import com.adimkilidi.BlockerAccessibilityService
import com.adimkilidi.Notifier
import com.adimkilidi.Prefs

/** Kurulum/izin durumlarının anlık görüntüsü. */
data class SetupState(
    val loaded: Boolean = false,
    val hcAvailable: Boolean = false,
    val healthPerm: Boolean = false,
    val backgroundPerm: Boolean = false,
    val accessibility: Boolean = false,
    val battery: Boolean = false,
    val notifications: Boolean = false,
) {
    /** Kilidin çalışması için şart olanlar. */
    val essentialsReady get() = hcAvailable && healthPerm && accessibility

    val missingCount get() = listOf(
        hcAvailable, healthPerm && backgroundPerm, accessibility, battery
    ).count { !it }

    companion object {
        suspend fun load(c: Context): SetupState {
            val hc = ActivityRepository.isAvailable(c)
            val granted = if (hc) runCatching { ActivityRepository(c).granted() }.getOrDefault(emptySet())
            else emptySet()
            val metric = Prefs.profile(c).metric
            return SetupState(
                loaded = true,
                hcAvailable = hc,
                healthPerm = ActivityRepository.readPermission(metric) in granted,
                backgroundPerm = ActivityRepository.BACKGROUND in granted,
                accessibility = isAccessibilityEnabled(c),
                battery = c.getSystemService(PowerManager::class.java)
                    .isIgnoringBatteryOptimizations(c.packageName),
                notifications = Notifier.canNotify(c),
            )
        }

        private fun isAccessibilityEnabled(c: Context): Boolean {
            val me = ComponentName(c, BlockerAccessibilityService::class.java).flattenToString()
            val list = Settings.Secure.getString(
                c.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            return list.split(':').any { it.equals(me, ignoreCase = true) }
        }
    }
}

/** Kurulum ekranlarındaki butonların tetiklediği sistem işlemleri (MainActivity uygular). */
interface SetupActions {
    fun installHealthConnect()
    fun requestHealthPermissions()
    fun openAppInfo()
    fun openAccessibilitySettings()
    fun requestBatteryExemption()
    fun requestNotifications()
}
