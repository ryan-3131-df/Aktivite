package com.adimkilidi

import android.content.Context
import android.util.Log
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.ActiveCaloriesBurnedRecord
import androidx.health.connect.client.records.DistanceRecord
import androidx.health.connect.client.records.StepsRecord
import androidx.health.connect.client.request.AggregateRequest
import androidx.health.connect.client.time.TimeRangeFilter
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId

/**
 * Günlük aktiviteyi Health Connect'ten okur.
 * Samsung Health verileri Health Connect'e yazar (Samsung Health > Ayarlar > Health Connect).
 */
class ActivityRepository(private val context: Context) {

    private val client by lazy { HealthConnectClient.getOrCreate(context) }

    companion object {
        fun readPermission(m: Metric) = when (m) {
            Metric.STEPS -> HealthPermission.getReadPermission(StepsRecord::class)
            Metric.DISTANCE -> HealthPermission.getReadPermission(DistanceRecord::class)
            Metric.CALORIES -> HealthPermission.getReadPermission(ActiveCaloriesBurnedRecord::class)
        }

        val BACKGROUND = HealthPermission.PERMISSION_READ_HEALTH_DATA_IN_BACKGROUND

        /** Tüm metrikler + arka plan okuma: profil sonradan değişirse yeniden izin gerekmesin. */
        val ALL_PERMISSIONS: Set<String> = Metric.entries.map { readPermission(it) }.toSet() + BACKGROUND

        fun isAvailable(c: Context) =
            HealthConnectClient.getSdkStatus(c) == HealthConnectClient.SDK_AVAILABLE
    }

    suspend fun granted(): Set<String> = client.permissionController.getGrantedPermissions()

    /** Gece yarısından şu ana kadar toplam (kaynaklar Health Connect tarafından tekilleştirilir). */
    suspend fun readToday(metric: Metric): Long {
        val start = LocalDate.now().atStartOfDay(ZoneId.systemDefault()).toInstant()
        val range = TimeRangeFilter.between(start, Instant.now())
        return when (metric) {
            Metric.STEPS -> client.aggregate(
                AggregateRequest(setOf(StepsRecord.COUNT_TOTAL), range)
            )[StepsRecord.COUNT_TOTAL] ?: 0L

            Metric.DISTANCE -> (client.aggregate(
                AggregateRequest(setOf(DistanceRecord.DISTANCE_TOTAL), range)
            )[DistanceRecord.DISTANCE_TOTAL]?.inMeters ?: 0.0).toLong()

            Metric.CALORIES -> (client.aggregate(
                AggregateRequest(setOf(ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL), range)
            )[ActiveCaloriesBurnedRecord.ACTIVE_CALORIES_TOTAL]?.inKilocalories ?: 0.0).toLong()
        }
    }

    /** Profildeki metriği okur ve önbelleğe yazar. Hata olursa null. */
    suspend fun refresh(): Long? = try {
        val metric = Prefs.profile(context).metric
        readToday(metric).also { Prefs.saveProgress(context, metric, it) }
    } catch (e: Exception) {
        Log.w("AdimKilidi", "Aktivite okunamadı", e)
        null
    }
}
